﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System
{
    public partial class MainForm : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Inventory.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;


        public MainForm()
        {
            InitializeComponent();


        }

        private void lblX_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure want to Exit application?", "Application Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSubForm_Click(object sender, EventArgs e)
        {
            new SubForm().Show();
            this.Hide();
        }

        private void btnClearMain_Form_Click(object sender, EventArgs e)
        {

            
            txtPrice.Clear();
            txtWeight.Clear();
            txtSID.Clear();
            comboBoxKarat.Text = "";
            CBItems.Text = "";


        }

      

        private void btnAddMainForm_Click(object sender, EventArgs e)
        {
            int SID = Convert.ToInt32(txtSID.Text);
            string karat = comboBoxKarat.SelectedItem.ToString();
            string name = CBItems.Text;
            string weight = txtWeight.Text;
            string Price = txtPrice.Text;

            this.DGVMainForm.Rows.Add(SID,karat, name, weight, Price);


            double totalAmt = 0;

            try
            {
                foreach (DataGridViewRow row in DGVMainForm.Rows)
                {

                    if (row.Cells["Column4"].Value != null)
                    {
                        totalAmt += Convert.ToDouble(row.Cells["Column4"].Value.ToString());

                    }
                }

                lbltotalMainForm.Text = totalAmt.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string karat = comboBoxKarat.SelectedItem.ToString();
            double weight = Convert.ToDouble(txtWeight.Text);
            double price = 0;
            double todayPrice = Convert.ToDouble(txtPureGoldPrice.Text);

            if (karat == "21K")
            {
                price = ((((todayPrice / 24) * 21) + 10000) / 8) * weight;
                txtPrice.Text = price.ToString();
            }
            else if (karat == "22K")
            {
                price = ((((todayPrice / 24) * 22) + 10000) / 8) * weight;
                txtPrice.Text = price.ToString();

            }
            else if (karat == "18K")
            {
                price = ((((todayPrice / 24) * 18) + 10000) / 8) * weight;
                txtPrice.Text = price.ToString();
            }
            else
            {
                MessageBox.Show("Please select a Karat value from dropdown list.");
            }
        }

        private void btnBillMainForm_Click(object sender, EventArgs e)
        {

            try
            {
                int SID = Convert.ToInt32(txtSID.Text);
                string customer = txtCustomerNameMainForm.Text;
                string karat = comboBoxKarat.SelectedItem.ToString();
                string Pname = CBItems.Text;
                double weight = Convert.ToDouble(txtWeight.Text);
                double price = Convert.ToDouble(lbltotalMainForm.Text);
                string date = dateTimePicker1.Value.Date.ToString("yyyyMMdd");
                
                cm = new SqlCommand("Insert into tblSales (SID, customer, Product, Weight, Karat, Date, Amount) values (@SID, @customer, @Pname, @weight, @karat, @date, @price)", con);
                cm.Parameters.AddWithValue("@SID", SID);
                cm.Parameters.AddWithValue("@customer", customer);
                cm.Parameters.AddWithValue("@Pname", Pname);
                cm.Parameters.AddWithValue("@weight", weight);
                cm.Parameters.AddWithValue("@karat", karat);
                cm.Parameters.AddWithValue("@date", date);
                cm.Parameters.AddWithValue("@price", price);

                if (Pname != "") {
                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show(" Bill Added Successfully!!");
                    clear();
                }
                else
                {
                    con.Close();
                    con.Open();
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }

             void clear()
            {
                CBItems.Text = "";
                txtPrice.Clear();
                txtWeight.Clear();
                comboBoxKarat.Text = "";

                txtCustomerNameMainForm.Clear();
                DGVMainForm.Rows.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new LoginForm().Show();
            this.Hide();

        }
    }
}
