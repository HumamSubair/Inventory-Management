﻿
namespace Inventory_System
{
    partial class SubForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnProductView = new System.Windows.Forms.Button();
            this.btnSearchProduct = new System.Windows.Forms.Button();
            this.txtSearchProduct = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DGVProduct = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.txtProductNo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnClearProduct = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGram = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProduct = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCategoryView = new System.Windows.Forms.Button();
            this.btnSearchCategory = new System.Windows.Forms.Button();
            this.txtSearchCategory = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.DGVCategory = new System.Windows.Forms.DataGridView();
            this.label16 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnUpdateCategory = new System.Windows.Forms.Button();
            this.txtCategoryID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnClearCategory = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCategoryName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnCustomerView = new System.Windows.Forms.Button();
            this.btnSearchCustomer = new System.Windows.Forms.Button();
            this.txtCusNoSearch = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DGVCustomer = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtCustomerNo = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnUpdateCustomer = new System.Windows.Forms.Button();
            this.btnClearCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCustomerContact = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnSalesView = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtCustomerSales = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtKarat = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnUpdateSales = new System.Windows.Forms.Button();
            this.btnClearSales = new System.Windows.Forms.Button();
            this.txtAmountSales = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDateSales = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtProductSales = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.btnSearchSales = new System.Windows.Forms.Button();
            this.txtSearchSales = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.DGVSales = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.btnUserView = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtUserPassword = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtUserEmail = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btnUpdateUser = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btnClearUser = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.txtUserFullName = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.btnSearchUser = new System.Windows.Forms.Button();
            this.txtSearchUser = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.DGVUSer = new System.Windows.Forms.DataGridView();
            this.label21 = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.btnMainForm = new System.Windows.Forms.Button();
            this.logout = new System.Windows.Forms.Button();
            this.lblNote = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVProduct)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCategory)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCustomer)).BeginInit();
            this.panel6.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSales)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVUSer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(858, 426);
            this.tabControl1.TabIndex = 29;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.btnProductView);
            this.tabPage1.Controls.Add(this.btnSearchProduct);
            this.tabPage1.Controls.Add(this.txtSearchProduct);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(850, 398);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Product";
            // 
            // btnProductView
            // 
            this.btnProductView.Location = new System.Drawing.Point(778, 363);
            this.btnProductView.Name = "btnProductView";
            this.btnProductView.Size = new System.Drawing.Size(66, 23);
            this.btnProductView.TabIndex = 32;
            this.btnProductView.Text = "View";
            this.btnProductView.UseVisualStyleBackColor = true;
            this.btnProductView.Click += new System.EventHandler(this.btnProductView_Click);
            // 
            // btnSearchProduct
            // 
            this.btnSearchProduct.Location = new System.Drawing.Point(319, 364);
            this.btnSearchProduct.Name = "btnSearchProduct";
            this.btnSearchProduct.Size = new System.Drawing.Size(61, 23);
            this.btnSearchProduct.TabIndex = 12;
            this.btnSearchProduct.Text = "Search";
            this.btnSearchProduct.UseVisualStyleBackColor = true;
            this.btnSearchProduct.Click += new System.EventHandler(this.btnSearchProduct_Click);
            // 
            // txtSearchProduct
            // 
            this.txtSearchProduct.Location = new System.Drawing.Point(162, 364);
            this.txtSearchProduct.Name = "txtSearchProduct";
            this.txtSearchProduct.Size = new System.Drawing.Size(132, 23);
            this.txtSearchProduct.TabIndex = 31;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.DGVProduct);
            this.panel2.Location = new System.Drawing.Point(295, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(549, 323);
            this.panel2.TabIndex = 2;
            // 
            // DGVProduct
            // 
            this.DGVProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVProduct.Location = new System.Drawing.Point(3, 6);
            this.DGVProduct.Name = "DGVProduct";
            this.DGVProduct.Size = new System.Drawing.Size(546, 317);
            this.DGVProduct.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(49, 367);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 15);
            this.label14.TabIndex = 30;
            this.label14.Text = "Product No";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnUpdateProduct);
            this.panel1.Controls.Add(this.txtProductNo);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.btnClearProduct);
            this.panel1.Controls.Add(this.btnAddProduct);
            this.panel1.Controls.Add(this.txtCategory);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtGram);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtPrice);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtProduct);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(10, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(279, 323);
            this.panel1.TabIndex = 1;
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Location = new System.Drawing.Point(127, 281);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(66, 23);
            this.btnUpdateProduct.TabIndex = 12;
            this.btnUpdateProduct.Text = "Update";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // txtProductNo
            // 
            this.txtProductNo.Location = new System.Drawing.Point(128, 72);
            this.txtProductNo.Name = "txtProductNo";
            this.txtProductNo.Size = new System.Drawing.Size(133, 23);
            this.txtProductNo.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 80);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 15);
            this.label13.TabIndex = 10;
            this.label13.Text = "Product No";
            // 
            // btnClearProduct
            // 
            this.btnClearProduct.Location = new System.Drawing.Point(58, 281);
            this.btnClearProduct.Name = "btnClearProduct";
            this.btnClearProduct.Size = new System.Drawing.Size(61, 23);
            this.btnClearProduct.TabIndex = 9;
            this.btnClearProduct.Text = "Clear";
            this.btnClearProduct.UseVisualStyleBackColor = true;
            this.btnClearProduct.Click += new System.EventHandler(this.btnClearProduct_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(199, 281);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(61, 23);
            this.btnAddProduct.TabIndex = 3;
            this.btnAddProduct.Text = "Add";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // txtCategory
            // 
            this.txtCategory.Location = new System.Drawing.Point(127, 229);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(133, 23);
            this.txtCategory.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Category ID";
            // 
            // txtGram
            // 
            this.txtGram.Location = new System.Drawing.Point(127, 191);
            this.txtGram.Name = "txtGram";
            this.txtGram.Size = new System.Drawing.Size(133, 23);
            this.txtGram.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Gram";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(71, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Add Product";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(127, 151);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(133, 23);
            this.txtPrice.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Price";
            // 
            // txtProduct
            // 
            this.txtProduct.Location = new System.Drawing.Point(127, 110);
            this.txtProduct.Name = "txtProduct";
            this.txtProduct.Size = new System.Drawing.Size(133, 23);
            this.txtProduct.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.btnCategoryView);
            this.tabPage2.Controls.Add(this.btnSearchCategory);
            this.tabPage2.Controls.Add(this.txtSearchCategory);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(850, 398);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Category";
            // 
            // btnCategoryView
            // 
            this.btnCategoryView.Location = new System.Drawing.Point(775, 366);
            this.btnCategoryView.Name = "btnCategoryView";
            this.btnCategoryView.Size = new System.Drawing.Size(66, 23);
            this.btnCategoryView.TabIndex = 15;
            this.btnCategoryView.Text = "View";
            this.btnCategoryView.UseVisualStyleBackColor = true;
            this.btnCategoryView.Click += new System.EventHandler(this.btnCategoryView_Click);
            // 
            // btnSearchCategory
            // 
            this.btnSearchCategory.Location = new System.Drawing.Point(312, 367);
            this.btnSearchCategory.Name = "btnSearchCategory";
            this.btnSearchCategory.Size = new System.Drawing.Size(66, 23);
            this.btnSearchCategory.TabIndex = 13;
            this.btnSearchCategory.Text = "Search";
            this.btnSearchCategory.UseVisualStyleBackColor = true;
            this.btnSearchCategory.Click += new System.EventHandler(this.btnSearchCategory_Click);
            // 
            // txtSearchCategory
            // 
            this.txtSearchCategory.Location = new System.Drawing.Point(155, 367);
            this.txtSearchCategory.Name = "txtSearchCategory";
            this.txtSearchCategory.Size = new System.Drawing.Size(133, 23);
            this.txtSearchCategory.TabIndex = 14;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.DGVCategory);
            this.panel3.Location = new System.Drawing.Point(312, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(532, 322);
            this.panel3.TabIndex = 4;
            // 
            // DGVCategory
            // 
            this.DGVCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVCategory.Location = new System.Drawing.Point(8, 3);
            this.DGVCategory.Name = "DGVCategory";
            this.DGVCategory.Size = new System.Drawing.Size(521, 316);
            this.DGVCategory.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(45, 375);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 15);
            this.label16.TabIndex = 13;
            this.label16.Text = "Category_ID";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnUpdateCategory);
            this.panel4.Controls.Add(this.txtCategoryID);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.btnClearCategory);
            this.panel4.Controls.Add(this.btnAddCategory);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.txtCategoryName);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Location = new System.Drawing.Point(27, 27);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(279, 322);
            this.panel4.TabIndex = 3;
            // 
            // btnUpdateCategory
            // 
            this.btnUpdateCategory.Location = new System.Drawing.Point(127, 269);
            this.btnUpdateCategory.Name = "btnUpdateCategory";
            this.btnUpdateCategory.Size = new System.Drawing.Size(66, 23);
            this.btnUpdateCategory.TabIndex = 12;
            this.btnUpdateCategory.Text = "Update";
            this.btnUpdateCategory.UseVisualStyleBackColor = true;
            this.btnUpdateCategory.Click += new System.EventHandler(this.btnUpdateCat_Click);
            // 
            // txtCategoryID
            // 
            this.txtCategoryID.Location = new System.Drawing.Point(127, 79);
            this.txtCategoryID.Name = "txtCategoryID";
            this.txtCategoryID.Size = new System.Drawing.Size(133, 23);
            this.txtCategoryID.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 15);
            this.label15.TabIndex = 10;
            this.label15.Text = "Category_ID";
            // 
            // btnClearCategory
            // 
            this.btnClearCategory.Location = new System.Drawing.Point(57, 269);
            this.btnClearCategory.Name = "btnClearCategory";
            this.btnClearCategory.Size = new System.Drawing.Size(61, 23);
            this.btnClearCategory.TabIndex = 9;
            this.btnClearCategory.Text = "Clear";
            this.btnClearCategory.UseVisualStyleBackColor = true;
            this.btnClearCategory.Click += new System.EventHandler(this.btnClearCategory_Click);
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Location = new System.Drawing.Point(199, 269);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(61, 23);
            this.btnAddCategory.TabIndex = 3;
            this.btnAddCategory.Text = "Add";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(71, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 23);
            this.label8.TabIndex = 4;
            this.label8.Text = "Add Category";
            // 
            // txtCategoryName
            // 
            this.txtCategoryName.Location = new System.Drawing.Point(127, 125);
            this.txtCategoryName.Name = "txtCategoryName";
            this.txtCategoryName.Size = new System.Drawing.Size(133, 23);
            this.txtCategoryName.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 133);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "Category";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage3.Controls.Add(this.btnCustomerView);
            this.tabPage3.Controls.Add(this.btnSearchCustomer);
            this.tabPage3.Controls.Add(this.txtCusNoSearch);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.panel5);
            this.tabPage3.Controls.Add(this.panel6);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(850, 398);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Customer";
            // 
            // btnCustomerView
            // 
            this.btnCustomerView.Location = new System.Drawing.Point(775, 362);
            this.btnCustomerView.Name = "btnCustomerView";
            this.btnCustomerView.Size = new System.Drawing.Size(66, 23);
            this.btnCustomerView.TabIndex = 16;
            this.btnCustomerView.Text = "View";
            this.btnCustomerView.UseVisualStyleBackColor = true;
            this.btnCustomerView.Click += new System.EventHandler(this.btnCustomerView_Click);
            // 
            // btnSearchCustomer
            // 
            this.btnSearchCustomer.Location = new System.Drawing.Point(308, 362);
            this.btnSearchCustomer.Name = "btnSearchCustomer";
            this.btnSearchCustomer.Size = new System.Drawing.Size(66, 23);
            this.btnSearchCustomer.TabIndex = 13;
            this.btnSearchCustomer.Text = "Search";
            this.btnSearchCustomer.UseVisualStyleBackColor = true;
            this.btnSearchCustomer.Click += new System.EventHandler(this.btnSearchCus_Click);
            // 
            // txtCusNoSearch
            // 
            this.txtCusNoSearch.Location = new System.Drawing.Point(158, 362);
            this.txtCusNoSearch.Name = "txtCusNoSearch";
            this.txtCusNoSearch.Size = new System.Drawing.Size(133, 23);
            this.txtCusNoSearch.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(41, 366);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 15);
            this.label18.TabIndex = 13;
            this.label18.Text = "Customer No";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.DGVCustomer);
            this.panel5.Location = new System.Drawing.Point(312, 27);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(532, 321);
            this.panel5.TabIndex = 4;
            // 
            // DGVCustomer
            // 
            this.DGVCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVCustomer.Location = new System.Drawing.Point(8, 3);
            this.DGVCustomer.Name = "DGVCustomer";
            this.DGVCustomer.Size = new System.Drawing.Size(521, 315);
            this.DGVCustomer.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtCustomerNo);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.btnUpdateCustomer);
            this.panel6.Controls.Add(this.btnClearCustomer);
            this.panel6.Controls.Add(this.btnAddCustomer);
            this.panel6.Controls.Add(this.txtCustomerAddress);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.txtCustomerContact);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.txtCustomerName);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Location = new System.Drawing.Point(27, 27);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(279, 321);
            this.panel6.TabIndex = 3;
            // 
            // txtCustomerNo
            // 
            this.txtCustomerNo.Location = new System.Drawing.Point(134, 77);
            this.txtCustomerNo.Name = "txtCustomerNo";
            this.txtCustomerNo.Size = new System.Drawing.Size(133, 23);
            this.txtCustomerNo.TabIndex = 12;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 81);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 15);
            this.label17.TabIndex = 11;
            this.label17.Text = "Customer No";
            // 
            // btnUpdateCustomer
            // 
            this.btnUpdateCustomer.Location = new System.Drawing.Point(134, 278);
            this.btnUpdateCustomer.Name = "btnUpdateCustomer";
            this.btnUpdateCustomer.Size = new System.Drawing.Size(66, 23);
            this.btnUpdateCustomer.TabIndex = 10;
            this.btnUpdateCustomer.Text = "Update";
            this.btnUpdateCustomer.UseVisualStyleBackColor = true;
            this.btnUpdateCustomer.Click += new System.EventHandler(this.btnUpdateCustomer_Click);
            // 
            // btnClearCustomer
            // 
            this.btnClearCustomer.Location = new System.Drawing.Point(63, 278);
            this.btnClearCustomer.Name = "btnClearCustomer";
            this.btnClearCustomer.Size = new System.Drawing.Size(61, 23);
            this.btnClearCustomer.TabIndex = 9;
            this.btnClearCustomer.Text = "Clear";
            this.btnClearCustomer.UseVisualStyleBackColor = true;
            this.btnClearCustomer.Click += new System.EventHandler(this.btnClearCustomer_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(206, 278);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(61, 23);
            this.btnAddCustomer.TabIndex = 3;
            this.btnAddCustomer.Text = "Add";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Location = new System.Drawing.Point(134, 200);
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(133, 23);
            this.txtCustomerAddress.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(65, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(156, 23);
            this.label9.TabIndex = 4;
            this.label9.Text = "Add Customer";
            // 
            // txtCustomerContact
            // 
            this.txtCustomerContact.Location = new System.Drawing.Point(134, 158);
            this.txtCustomerContact.Name = "txtCustomerContact";
            this.txtCustomerContact.Size = new System.Drawing.Size(133, 23);
            this.txtCustomerContact.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "Contact No.";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(134, 118);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(133, 23);
            this.txtCustomerName.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 122);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 15);
            this.label12.TabIndex = 0;
            this.label12.Text = "Customer Name";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage4.Controls.Add(this.btnSalesView);
            this.tabPage4.Controls.Add(this.panel8);
            this.tabPage4.Controls.Add(this.btnSearchSales);
            this.tabPage4.Controls.Add(this.txtSearchSales);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.panel7);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(850, 398);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sales";
            // 
            // btnSalesView
            // 
            this.btnSalesView.Location = new System.Drawing.Point(775, 364);
            this.btnSalesView.Name = "btnSalesView";
            this.btnSalesView.Size = new System.Drawing.Size(66, 23);
            this.btnSalesView.TabIndex = 33;
            this.btnSalesView.Text = "View";
            this.btnSalesView.UseVisualStyleBackColor = true;
            this.btnSalesView.Click += new System.EventHandler(this.btnSalesView_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label33);
            this.panel8.Controls.Add(this.txtSID);
            this.panel8.Controls.Add(this.txtWeight);
            this.panel8.Controls.Add(this.label32);
            this.panel8.Controls.Add(this.txtCustomerSales);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.txtKarat);
            this.panel8.Controls.Add(this.label20);
            this.panel8.Controls.Add(this.btnUpdateSales);
            this.panel8.Controls.Add(this.btnClearSales);
            this.panel8.Controls.Add(this.txtAmountSales);
            this.panel8.Controls.Add(this.label22);
            this.panel8.Controls.Add(this.label23);
            this.panel8.Controls.Add(this.txtDateSales);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.txtProductSales);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Location = new System.Drawing.Point(6, 23);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(279, 365);
            this.panel8.TabIndex = 32;
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(133, 121);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(133, 23);
            this.txtWeight.TabIndex = 16;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(13, 128);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 15);
            this.label32.TabIndex = 15;
            this.label32.Text = "Weight";
            // 
            // txtCustomerSales
            // 
            this.txtCustomerSales.Location = new System.Drawing.Point(133, 47);
            this.txtCustomerSales.Name = "txtCustomerSales";
            this.txtCustomerSales.Size = new System.Drawing.Size(133, 23);
            this.txtCustomerSales.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Customer";
            // 
            // txtKarat
            // 
            this.txtKarat.Location = new System.Drawing.Point(134, 159);
            this.txtKarat.Name = "txtKarat";
            this.txtKarat.Size = new System.Drawing.Size(133, 23);
            this.txtKarat.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 15);
            this.label20.TabIndex = 11;
            this.label20.Text = "Karat";
            // 
            // btnUpdateSales
            // 
            this.btnUpdateSales.Location = new System.Drawing.Point(204, 338);
            this.btnUpdateSales.Name = "btnUpdateSales";
            this.btnUpdateSales.Size = new System.Drawing.Size(66, 23);
            this.btnUpdateSales.TabIndex = 10;
            this.btnUpdateSales.Text = "Update";
            this.btnUpdateSales.UseVisualStyleBackColor = true;
            this.btnUpdateSales.Click += new System.EventHandler(this.btnUpdateSales_Click);
            // 
            // btnClearSales
            // 
            this.btnClearSales.Location = new System.Drawing.Point(133, 338);
            this.btnClearSales.Name = "btnClearSales";
            this.btnClearSales.Size = new System.Drawing.Size(61, 23);
            this.btnClearSales.TabIndex = 9;
            this.btnClearSales.Text = "Clear";
            this.btnClearSales.UseVisualStyleBackColor = true;
            this.btnClearSales.Click += new System.EventHandler(this.btnClearSales_Click);
            // 
            // txtAmountSales
            // 
            this.txtAmountSales.Location = new System.Drawing.Point(134, 238);
            this.txtAmountSales.Name = "txtAmountSales";
            this.txtAmountSales.Size = new System.Drawing.Size(133, 23);
            this.txtAmountSales.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(16, 246);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 15);
            this.label22.TabIndex = 5;
            this.label22.Text = "Amount";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DimGray;
            this.label23.Location = new System.Drawing.Point(65, 7);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(110, 23);
            this.label23.TabIndex = 4;
            this.label23.Text = "Add Sales";
            // 
            // txtDateSales
            // 
            this.txtDateSales.Location = new System.Drawing.Point(134, 198);
            this.txtDateSales.Name = "txtDateSales";
            this.txtDateSales.Size = new System.Drawing.Size(133, 23);
            this.txtDateSales.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 206);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 15);
            this.label24.TabIndex = 2;
            this.label24.Text = "Date";
            // 
            // txtProductSales
            // 
            this.txtProductSales.Location = new System.Drawing.Point(133, 84);
            this.txtProductSales.Name = "txtProductSales";
            this.txtProductSales.Size = new System.Drawing.Size(133, 23);
            this.txtProductSales.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(61, 15);
            this.label25.TabIndex = 0;
            this.label25.Text = "Product";
            // 
            // btnSearchSales
            // 
            this.btnSearchSales.Location = new System.Drawing.Point(566, 365);
            this.btnSearchSales.Name = "btnSearchSales";
            this.btnSearchSales.Size = new System.Drawing.Size(66, 23);
            this.btnSearchSales.TabIndex = 17;
            this.btnSearchSales.Text = "Search";
            this.btnSearchSales.UseVisualStyleBackColor = true;
            this.btnSearchSales.Click += new System.EventHandler(this.btnSearchSales_Click);
            // 
            // txtSearchSales
            // 
            this.txtSearchSales.Location = new System.Drawing.Point(416, 365);
            this.txtSearchSales.Name = "txtSearchSales";
            this.txtSearchSales.Size = new System.Drawing.Size(133, 23);
            this.txtSearchSales.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(299, 369);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 15);
            this.label19.TabIndex = 18;
            this.label19.Text = "Sales No";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.DGVSales);
            this.panel7.Location = new System.Drawing.Point(290, 23);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(554, 322);
            this.panel7.TabIndex = 16;
            // 
            // DGVSales
            // 
            this.DGVSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSales.Location = new System.Drawing.Point(8, 7);
            this.DGVSales.Name = "DGVSales";
            this.DGVSales.Size = new System.Drawing.Size(543, 312);
            this.DGVSales.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tabPage5.Controls.Add(this.lblNote);
            this.tabPage5.Controls.Add(this.btnAddUser);
            this.tabPage5.Controls.Add(this.btnUserView);
            this.tabPage5.Controls.Add(this.panel10);
            this.tabPage5.Controls.Add(this.btnSearchUser);
            this.tabPage5.Controls.Add(this.txtSearchUser);
            this.tabPage5.Controls.Add(this.panel9);
            this.tabPage5.Controls.Add(this.label21);
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(850, 398);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "User";
            // 
            // btnAddUser
            // 
            this.btnAddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAddUser.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUser.ForeColor = System.Drawing.Color.White;
            this.btnAddUser.Location = new System.Drawing.Point(589, 362);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(87, 23);
            this.btnAddUser.TabIndex = 22;
            this.btnAddUser.Text = "Add User";
            this.btnAddUser.UseVisualStyleBackColor = false;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // btnUserView
            // 
            this.btnUserView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnUserView.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserView.ForeColor = System.Drawing.Color.White;
            this.btnUserView.Location = new System.Drawing.Point(696, 362);
            this.btnUserView.Name = "btnUserView";
            this.btnUserView.Size = new System.Drawing.Size(66, 23);
            this.btnUserView.TabIndex = 21;
            this.btnUserView.Text = "View";
            this.btnUserView.UseVisualStyleBackColor = false;
            this.btnUserView.Click += new System.EventHandler(this.btnUserView_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txtUserPassword);
            this.panel10.Controls.Add(this.label31);
            this.panel10.Controls.Add(this.txtUserEmail);
            this.panel10.Controls.Add(this.label29);
            this.panel10.Controls.Add(this.btnUpdateUser);
            this.panel10.Controls.Add(this.txtUserName);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Controls.Add(this.btnClearUser);
            this.panel10.Controls.Add(this.label27);
            this.panel10.Controls.Add(this.txtUserFullName);
            this.panel10.Controls.Add(this.label28);
            this.panel10.Location = new System.Drawing.Point(27, 26);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(279, 313);
            this.panel10.TabIndex = 20;
            // 
            // txtUserPassword
            // 
            this.txtUserPassword.Location = new System.Drawing.Point(127, 117);
            this.txtUserPassword.Name = "txtUserPassword";
            this.txtUserPassword.Size = new System.Drawing.Size(133, 23);
            this.txtUserPassword.TabIndex = 16;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(18, 202);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(43, 15);
            this.label31.TabIndex = 15;
            this.label31.Text = "Email";
            // 
            // txtUserEmail
            // 
            this.txtUserEmail.Location = new System.Drawing.Point(128, 199);
            this.txtUserEmail.Name = "txtUserEmail";
            this.txtUserEmail.Size = new System.Drawing.Size(133, 23);
            this.txtUserEmail.TabIndex = 14;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(18, 120);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 15);
            this.label29.TabIndex = 13;
            this.label29.Text = "Password";
            // 
            // btnUpdateUser
            // 
            this.btnUpdateUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnUpdateUser.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateUser.ForeColor = System.Drawing.Color.White;
            this.btnUpdateUser.Location = new System.Drawing.Point(192, 271);
            this.btnUpdateUser.Name = "btnUpdateUser";
            this.btnUpdateUser.Size = new System.Drawing.Size(66, 23);
            this.btnUpdateUser.TabIndex = 12;
            this.btnUpdateUser.Text = "Update";
            this.btnUpdateUser.UseVisualStyleBackColor = false;
            this.btnUpdateUser.Click += new System.EventHandler(this.btnUpdateUser_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(127, 78);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(133, 23);
            this.txtUserName.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 86);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 15);
            this.label26.TabIndex = 10;
            this.label26.Text = "User Name";
            // 
            // btnClearUser
            // 
            this.btnClearUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClearUser.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearUser.ForeColor = System.Drawing.Color.White;
            this.btnClearUser.Location = new System.Drawing.Point(122, 271);
            this.btnClearUser.Name = "btnClearUser";
            this.btnClearUser.Size = new System.Drawing.Size(61, 23);
            this.btnClearUser.TabIndex = 9;
            this.btnClearUser.Text = "Clear";
            this.btnClearUser.UseVisualStyleBackColor = false;
            this.btnClearUser.Click += new System.EventHandler(this.btnClearUser_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.DimGray;
            this.label27.Location = new System.Drawing.Point(71, 17);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 23);
            this.label27.TabIndex = 4;
            this.label27.Text = "Add User";
            // 
            // txtUserFullName
            // 
            this.txtUserFullName.Location = new System.Drawing.Point(127, 158);
            this.txtUserFullName.Name = "txtUserFullName";
            this.txtUserFullName.Size = new System.Drawing.Size(133, 23);
            this.txtUserFullName.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(18, 161);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 15);
            this.label28.TabIndex = 0;
            this.label28.Text = "Full Name";
            // 
            // btnSearchUser
            // 
            this.btnSearchUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSearchUser.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchUser.ForeColor = System.Drawing.Color.White;
            this.btnSearchUser.Location = new System.Drawing.Point(312, 363);
            this.btnSearchUser.Name = "btnSearchUser";
            this.btnSearchUser.Size = new System.Drawing.Size(66, 23);
            this.btnSearchUser.TabIndex = 17;
            this.btnSearchUser.Text = "Search";
            this.btnSearchUser.UseVisualStyleBackColor = false;
            this.btnSearchUser.Click += new System.EventHandler(this.btnSearchUser_Click);
            // 
            // txtSearchUser
            // 
            this.txtSearchUser.Location = new System.Drawing.Point(155, 363);
            this.txtSearchUser.Name = "txtSearchUser";
            this.txtSearchUser.Size = new System.Drawing.Size(133, 23);
            this.txtSearchUser.TabIndex = 19;
            this.txtSearchUser.TextChanged += new System.EventHandler(this.txtSearchUser_TextChanged);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.DGVUSer);
            this.panel9.Location = new System.Drawing.Point(336, 26);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(459, 313);
            this.panel9.TabIndex = 16;
            // 
            // DGVUSer
            // 
            this.DGVUSer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVUSer.Location = new System.Drawing.Point(8, 12);
            this.DGVUSer.Name = "DGVUSer";
            this.DGVUSer.Size = new System.Drawing.Size(442, 287);
            this.DGVUSer.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(45, 371);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 15);
            this.label21.TabIndex = 18;
            this.label21.Text = "User Name";
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX.ForeColor = System.Drawing.Color.Red;
            this.lblX.Location = new System.Drawing.Point(840, 470);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(20, 18);
            this.lblX.TabIndex = 1;
            this.lblX.Text = "X";
            this.lblX.Click += new System.EventHandler(this.lblX_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(336, 445);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label30.Location = new System.Drawing.Point(421, 439);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(268, 49);
            this.label30.TabIndex = 31;
            this.label30.Text = "HappyJewllery";
            // 
            // txtSID
            // 
            this.txtSID.Location = new System.Drawing.Point(133, 283);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(133, 23);
            this.txtSID.TabIndex = 17;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(16, 291);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 15);
            this.label33.TabIndex = 34;
            this.label33.Text = "Sales No";
            // 
            // btnMainForm
            // 
            this.btnMainForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnMainForm.Font = new System.Drawing.Font("Lucida Calligraphy", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainForm.ForeColor = System.Drawing.Color.White;
            this.btnMainForm.Location = new System.Drawing.Point(16, 443);
            this.btnMainForm.Name = "btnMainForm";
            this.btnMainForm.Size = new System.Drawing.Size(145, 43);
            this.btnMainForm.TabIndex = 32;
            this.btnMainForm.Text = "Main Form";
            this.btnMainForm.UseVisualStyleBackColor = false;
            this.btnMainForm.Click += new System.EventHandler(this.btnMainForm_Click);
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.White;
            this.logout.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.logout.Location = new System.Drawing.Point(167, 447);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(155, 35);
            this.logout.TabIndex = 56;
            this.logout.Text = "Log out";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Lucida Sans", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.ForeColor = System.Drawing.Color.Red;
            this.lblNote.Location = new System.Drawing.Point(156, 350);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(106, 9);
            this.lblNote.TabIndex = 23;
            this.lblNote.Text = "* Type User Name to Find";
            // 
            // SubForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 494);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.btnMainForm);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SubForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SubForm";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVProduct)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVCategory)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVCustomer)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVSales)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVUSer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGram;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCategory;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnClearProduct;
        private System.Windows.Forms.DataGridView DGVProduct;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView DGVCategory;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnClearCategory;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCategoryName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView DGVCustomer;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnClearCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCustomerContact;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProductNo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSearchProduct;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnSearchProduct;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.TextBox txtCategoryID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnUpdateCategory;
        private System.Windows.Forms.TextBox txtSearchCategory;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnSearchCategory;
        private System.Windows.Forms.Button btnUpdateCustomer;
        private System.Windows.Forms.TextBox txtCustomerNo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtCusNoSearch;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnSearchCustomer;
        private System.Windows.Forms.Button btnSearchSales;
        private System.Windows.Forms.TextBox txtSearchSales;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView DGVSales;
        private System.Windows.Forms.TextBox txtProduct;
        private System.Windows.Forms.Button btnSearchUser;
        private System.Windows.Forms.TextBox txtSearchUser;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView DGVUSer;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtUserEmail;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnUpdateUser;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnClearUser;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtUserFullName;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtCustomerSales;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtKarat;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnUpdateSales;
        private System.Windows.Forms.Button btnClearSales;
        private System.Windows.Forms.TextBox txtAmountSales;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDateSales;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtProductSales;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnCategoryView;
        private System.Windows.Forms.Button btnProductView;
        private System.Windows.Forms.Button btnCustomerView;
        private System.Windows.Forms.Button btnSalesView;
        private System.Windows.Forms.Button btnUserView;
        private System.Windows.Forms.TextBox txtUserPassword;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnMainForm;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label lblNote;
    }
}