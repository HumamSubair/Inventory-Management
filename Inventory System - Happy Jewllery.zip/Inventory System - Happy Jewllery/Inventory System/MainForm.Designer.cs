﻿
namespace Inventory_System
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.lblX = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DGVMainForm = new System.Windows.Forms.DataGridView();
            this.btnSubForm = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCustomerNameMainForm = new System.Windows.Forms.TextBox();
            this.btnBillMainForm = new System.Windows.Forms.Button();
            this.btnClearMain_Form = new System.Windows.Forms.Button();
            this.txtPureGoldPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnAddMainForm = new System.Windows.Forms.Button();
            this.comboBoxKarat = new System.Windows.Forms.ComboBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.lbltotalMainForm = new System.Windows.Forms.Label();
            this.logout = new System.Windows.Forms.Button();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CBItems = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMainForm)).BeginInit();
            this.SuspendLayout();
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX.ForeColor = System.Drawing.Color.Red;
            this.lblX.Location = new System.Drawing.Point(593, 9);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(20, 18);
            this.lblX.TabIndex = 1;
            this.lblX.Text = "X";
            this.lblX.Click += new System.EventHandler(this.lblX_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(146, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(458, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Inventory Management System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(178, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(415, 67);
            this.label2.TabIndex = 27;
            this.label2.Text = "Happy Jewellery";
            // 
            // DGVMainForm
            // 
            this.DGVMainForm.BackgroundColor = System.Drawing.Color.Gray;
            this.DGVMainForm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGVMainForm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVMainForm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column3,
            this.Column2,
            this.Column1,
            this.Column4});
            this.DGVMainForm.Location = new System.Drawing.Point(251, 179);
            this.DGVMainForm.Name = "DGVMainForm";
            this.DGVMainForm.Size = new System.Drawing.Size(356, 234);
            this.DGVMainForm.TabIndex = 28;
            // 
            // btnSubForm
            // 
            this.btnSubForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnSubForm.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubForm.ForeColor = System.Drawing.Color.White;
            this.btnSubForm.Location = new System.Drawing.Point(15, 465);
            this.btnSubForm.Name = "btnSubForm";
            this.btnSubForm.Size = new System.Drawing.Size(155, 35);
            this.btnSubForm.TabIndex = 32;
            this.btnSubForm.Text = "Inventory";
            this.btnSubForm.UseVisualStyleBackColor = false;
            this.btnSubForm.Click += new System.EventHandler(this.btnSubForm_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(354, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Customer Name";
            // 
            // txtCustomerNameMainForm
            // 
            this.txtCustomerNameMainForm.Location = new System.Drawing.Point(442, 134);
            this.txtCustomerNameMainForm.Name = "txtCustomerNameMainForm";
            this.txtCustomerNameMainForm.Size = new System.Drawing.Size(165, 20);
            this.txtCustomerNameMainForm.TabIndex = 34;
            // 
            // btnBillMainForm
            // 
            this.btnBillMainForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnBillMainForm.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillMainForm.ForeColor = System.Drawing.Color.White;
            this.btnBillMainForm.Location = new System.Drawing.Point(400, 462);
            this.btnBillMainForm.Name = "btnBillMainForm";
            this.btnBillMainForm.Size = new System.Drawing.Size(207, 38);
            this.btnBillMainForm.TabIndex = 35;
            this.btnBillMainForm.Text = "Bill";
            this.btnBillMainForm.UseVisualStyleBackColor = false;
            this.btnBillMainForm.Click += new System.EventHandler(this.btnBillMainForm_Click);
            // 
            // btnClearMain_Form
            // 
            this.btnClearMain_Form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnClearMain_Form.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearMain_Form.ForeColor = System.Drawing.Color.White;
            this.btnClearMain_Form.Location = new System.Drawing.Point(17, 401);
            this.btnClearMain_Form.Name = "btnClearMain_Form";
            this.btnClearMain_Form.Size = new System.Drawing.Size(68, 23);
            this.btnClearMain_Form.TabIndex = 36;
            this.btnClearMain_Form.Text = "Clear";
            this.btnClearMain_Form.UseVisualStyleBackColor = false;
            this.btnClearMain_Form.Click += new System.EventHandler(this.btnClearMain_Form_Click);
            // 
            // txtPureGoldPrice
            // 
            this.txtPureGoldPrice.Location = new System.Drawing.Point(246, 134);
            this.txtPureGoldPrice.Name = "txtPureGoldPrice";
            this.txtPureGoldPrice.Size = new System.Drawing.Size(85, 20);
            this.txtPureGoldPrice.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(158, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 37;
            this.label4.Text = "Gold Price ( 24K)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(20, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "Karat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(20, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 41;
            this.label6.Text = "Item";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(20, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 42;
            this.label7.Text = "Weight";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(20, 360);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 43;
            this.label8.Text = "Price";
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(79, 309);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(153, 20);
            this.txtWeight.TabIndex = 46;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(79, 353);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(153, 20);
            this.txtPrice.TabIndex = 47;
            // 
            // btnAddMainForm
            // 
            this.btnAddMainForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAddMainForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMainForm.ForeColor = System.Drawing.Color.White;
            this.btnAddMainForm.Location = new System.Drawing.Point(176, 401);
            this.btnAddMainForm.Name = "btnAddMainForm";
            this.btnAddMainForm.Size = new System.Drawing.Size(57, 23);
            this.btnAddMainForm.TabIndex = 48;
            this.btnAddMainForm.Text = "Add";
            this.btnAddMainForm.UseVisualStyleBackColor = false;
            this.btnAddMainForm.Click += new System.EventHandler(this.btnAddMainForm_Click);
            // 
            // comboBoxKarat
            // 
            this.comboBoxKarat.FormattingEnabled = true;
            this.comboBoxKarat.Items.AddRange(new object[] {
            "21K",
            "22K",
            "18K"});
            this.comboBoxKarat.Location = new System.Drawing.Point(79, 221);
            this.comboBoxKarat.Name = "comboBoxKarat";
            this.comboBoxKarat.Size = new System.Drawing.Size(153, 21);
            this.comboBoxKarat.TabIndex = 49;
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.ForeColor = System.Drawing.Color.White;
            this.btnCalculate.Location = new System.Drawing.Point(91, 401);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(79, 23);
            this.btnCalculate.TabIndex = 50;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(15, 430);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(217, 20);
            this.dateTimePicker1.TabIndex = 51;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(20, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 52;
            this.label9.Text = "SID";
            // 
            // txtSID
            // 
            this.txtSID.Location = new System.Drawing.Point(79, 179);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(153, 20);
            this.txtSID.TabIndex = 53;
            // 
            // lbltotalMainForm
            // 
            this.lbltotalMainForm.AutoSize = true;
            this.lbltotalMainForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalMainForm.ForeColor = System.Drawing.Color.White;
            this.lbltotalMainForm.Location = new System.Drawing.Point(456, 425);
            this.lbltotalMainForm.Name = "lbltotalMainForm";
            this.lbltotalMainForm.Size = new System.Drawing.Size(0, 24);
            this.lbltotalMainForm.TabIndex = 54;
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.logout.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.White;
            this.logout.Location = new System.Drawing.Point(211, 465);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(155, 35);
            this.logout.TabIndex = 55;
            this.logout.Text = "Log out";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.button1_Click);
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column5.HeaderText = "SID";
            this.Column5.Name = "Column5";
            this.Column5.Width = 50;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Karat";
            this.Column3.Name = "Column3";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Item Name";
            this.Column2.Name = "Column2";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.HeaderText = "Weight";
            this.Column1.Name = "Column1";
            this.Column1.Width = 66;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Price";
            this.Column4.Name = "Column4";
            // 
            // CBItems
            // 
            this.CBItems.FormattingEnabled = true;
            this.CBItems.Items.AddRange(new object[] {
            "Chain",
            "Bengles",
            "Bracelet",
            "Earrings",
            "RIng",
            "Sabona",
            "Necklace"});
            this.CBItems.Location = new System.Drawing.Point(79, 265);
            this.CBItems.Name = "CBItems";
            this.CBItems.Size = new System.Drawing.Size(153, 21);
            this.CBItems.TabIndex = 56;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(620, 509);
            this.Controls.Add(this.CBItems);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.lbltotalMainForm);
            this.Controls.Add(this.txtSID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.comboBoxKarat);
            this.Controls.Add(this.btnAddMainForm);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPureGoldPrice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnClearMain_Form);
            this.Controls.Add(this.btnBillMainForm);
            this.Controls.Add(this.txtCustomerNameMainForm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSubForm);
            this.Controls.Add(this.DGVMainForm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblX);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "s";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMainForm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView DGVMainForm;
        private System.Windows.Forms.Button btnSubForm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCustomerNameMainForm;
        private System.Windows.Forms.Button btnBillMainForm;
        private System.Windows.Forms.Button btnClearMain_Form;
        private System.Windows.Forms.TextBox txtPureGoldPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnAddMainForm;
        private System.Windows.Forms.ComboBox comboBoxKarat;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.Label lbltotalMainForm;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.ComboBox CBItems;
    }
}