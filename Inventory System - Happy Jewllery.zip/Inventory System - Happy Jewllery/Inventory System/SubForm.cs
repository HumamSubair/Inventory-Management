﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System
{

    public partial class SubForm : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Inventory.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        public SubForm()
        {
            InitializeComponent();
            btnUpdateProduct.Enabled = false;
            btnUpdateCustomer.Enabled = false;
            btnUpdateCategory.Enabled = false;
            btnUpdateSales.Enabled = false;
            btnUpdateUser.Enabled = false;
            lblNote.Visible = false;


        }



        private void btnUpdateCat_Click(object sender, EventArgs e)
        {
            string catID = txtCategoryID.Text;
            string cat = txtCategoryName.Text;

            try
            {

                cm = new SqlCommand("Update tblCategory set  CName = @cat where CID = @catID", con);
                cm.Parameters.AddWithValue("@catID", catID);
                cm.Parameters.AddWithValue("@cat", cat);
                con.Open();

                cm.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(cat + " Updated successfully!!");
                clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearchCus_Click(object sender, EventArgs e)
        {
            string search = txtCusNoSearch.Text;
            btnAddCustomer.Enabled = false;

            try
            {

                cm = new SqlCommand("select * from tblCustomer where CusID = @search", con);
                con.Open();
                cm.Parameters.AddWithValue("@search", search);

                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    txtCustomerNo.Text = dr.GetValue(0).ToString();
                    txtCustomerName.Text = dr.GetValue(1).ToString();
                    txtCustomerContact.Text = dr.GetValue(2).ToString();
                    txtCustomerAddress.Text = dr.GetValue(3).ToString();

                }
                else
                {
                    con.Close();
                    con.Open();
                }
                con.Close();

                btnUpdateCustomer.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            string catID = txtCategoryID.Text;
            string cat = txtCategoryName.Text;

            try
            {

                cm = new SqlCommand("Insert into tblCategory (CID, CName) values (@catID, @cat)",con);
                cm.Parameters.AddWithValue("@catID", catID);
                cm.Parameters.AddWithValue("@cat", cat);
                con.Open();
                
                cm.ExecuteNonQuery();
                con.Close();

                MessageBox.Show(cat + " Added!!");
                clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    private void lblX_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure want to Exit application?", "Application Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnCategoryView_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from tblCategory", con);
                con.Open();
                
                da.Fill(ds, "tblCategory");
                DGVCategory.DataSource = ds.Tables["tblCategory"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUserView_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from tbluser", con);
                con.Open();

                da.Fill(ds, "tbluser");
                DGVUSer.DataSource = ds.Tables["tbluser"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSalesView_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from tblSales", con);
                con.Open();

                da.Fill(ds, "tblSales");
                DGVSales.DataSource = ds.Tables["tblSales"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCustomerView_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from tblCustomer", con);
                con.Open();

                da.Fill(ds, "tblCustomer");
                DGVCustomer.DataSource = ds.Tables["tblCustomer"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnProductView_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from tblProduct", con);
                con.Open();

                da.Fill(ds, "tblProduct");
                DGVProduct.DataSource = ds.Tables["tblProduct"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            string ProNo = txtProductNo.Text;
            string Product = txtProduct.Text;
            string price = txtPrice.Text;
            string Gram = txtGram.Text;
            string CatID = txtCategory.Text;


            try
            {

                cm = new SqlCommand("Insert into tblProduct (PID, PName, Price, Gram, CID) values (@ProNo, @Product, @price, @Gram, @catID)", con);
                cm.Parameters.AddWithValue("@ProNo", ProNo);
                cm.Parameters.AddWithValue("@Product", Product);
                cm.Parameters.AddWithValue("@price", price);
                cm.Parameters.AddWithValue("@Gram", Gram);
                cm.Parameters.AddWithValue("@CatID", CatID);
                con.Open();

                cm.ExecuteNonQuery();
                con.Close();

                MessageBox.Show(Product + " Added Successfully!!");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            string CusNo = txtCustomerNo.Text;
            string CusName = txtCustomerName.Text;
            string Contact = txtCustomerContact.Text;
            string Address = txtCustomerAddress.Text;


            try
            {

                cm = new SqlCommand("Insert into tblCustomer (CusID, Name, Contact, Address) values (@CusNo, @CusName, @Contact, @Address)", con);
                cm.Parameters.AddWithValue("@CusNo", CusNo);
                cm.Parameters.AddWithValue("@CusName", CusName);
                cm.Parameters.AddWithValue("@Contact", Contact);
                cm.Parameters.AddWithValue("@Address", Address);
                con.Open();

                cm.ExecuteNonQuery();
                con.Close();

                MessageBox.Show(CusName + " Added Successfully!!");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClearProduct_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnClearCategory_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnClearCustomer_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnClearSales_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnClearUser_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            btnAddProduct.Enabled = false;
            string search = txtSearchProduct.Text;

            try
            {

                cm = new SqlCommand("select * from tblProduct where PID = @search", con);
                con.Open();
                cm.Parameters.AddWithValue("@search", search);

                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    txtProductNo.Text = dr.GetValue(0).ToString();
                    txtProduct.Text = dr.GetValue(1).ToString();
                    txtPrice.Text = dr.GetValue(2).ToString();
                    txtGram.Text = dr.GetValue(3).ToString();
                    txtCategory.Text = dr.GetValue(4).ToString();

                }
                else
                {
                    con.Close();
                    con.Open();
                }
                con.Close();

                btnUpdateProduct.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearchCategory_Click(object sender, EventArgs e)
        {
            string search = txtSearchCategory.Text;
            btnAddCategory.Enabled = false;

            try
            {

                cm = new SqlCommand("select * from tblCategory where CID = @search", con);
                con.Open();
                cm.Parameters.AddWithValue("@search", search);

                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    txtCategoryID.Text = dr.GetValue(0).ToString();
                    txtCategoryName.Text = dr.GetValue(1).ToString();
            
                }
                else
                {
                    con.Close();
                    con.Open();
                }
                con.Close();

                btnUpdateCategory.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnSearchSales_Click(object sender, EventArgs e)
        {
            string search = txtSearchSales.Text;

            try
            {

                cm = new SqlCommand("select * from tblSales where SID = @search", con);
                con.Open();
                cm.Parameters.AddWithValue("@search", search);

                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    txtCustomerSales.Text = dr.GetValue(0).ToString();
                    txtProductSales.Text = dr.GetValue(1).ToString();
                    txtWeight.Text = dr.GetValue(2).ToString();
                    txtKarat.Text = dr.GetValue(3).ToString();
                    txtDateSales.Text = dr.GetValue(4).ToString();
                    txtAmountSales.Text = dr.GetValue(5).ToString();
                    txtSID.Text = dr.GetValue(6).ToString();

                }
                else
                {
                    con.Close();
                    con.Open();
                }
                con.Close();

                btnUpdateSales.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            string search = txtSearchUser.Text;

            try
            {

                cm = new SqlCommand("select * from tblUser where UName = @search", con);
                con.Open();
                cm.Parameters.AddWithValue("@search", search);

                dr = cm.ExecuteReader();

                if (dr.Read())
                {
                    txtUserName.Text = dr.GetValue(0).ToString();
                    txtUserPassword.Text = dr.GetValue(1).ToString();
                    txtUserFullName.Text = dr.GetValue(2).ToString();
                    txtUserEmail.Text = dr.GetValue(3).ToString();


                }
                else
                {
                    con.Close();
                    con.Open();
                }
                con.Close();
                txtProductNo.Enabled = false;
                btnUpdateUser.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            string ProNo = txtProductNo.Text;
            string Product = txtProduct.Text;
            string price = txtPrice.Text;
            string Gram = txtGram.Text;
            string CatID = txtCategory.Text;

            try
            {

                cm = new SqlCommand("Update tblProduct set  PName = @Product, Price = @price, Gram = @Gram, CID =  @catID where PID = @ProNo", con);
                cm.Parameters.AddWithValue("@ProNo", ProNo);
                cm.Parameters.AddWithValue("@Product", Product);
                cm.Parameters.AddWithValue("@price", price);
                cm.Parameters.AddWithValue("@Gram", Gram);
                cm.Parameters.AddWithValue("@CatID", CatID);
                con.Open();

                cm.ExecuteNonQuery();
                con.Close();

                MessageBox.Show(Product + " Updated Successfully!!");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateCustomer_Click(object sender, EventArgs e)
        {
            string CusNo = txtCustomerNo.Text;
            string CusName = txtCustomerName.Text;
            string Contact = txtCustomerContact.Text;
            string Address = txtCustomerAddress.Text;


            try
            {

                cm = new SqlCommand("Update tblCustomer set Name = @CusName, Contact = @Contact, Address = @Address where CusID = @CusNo", con);
                cm.Parameters.AddWithValue("@CusNo", CusNo);
                cm.Parameters.AddWithValue("@CusName", CusName);
                cm.Parameters.AddWithValue("@Contact", Contact);
                cm.Parameters.AddWithValue("@Address", Address);
                con.Open();

                cm.ExecuteNonQuery();
                con.Close();

                MessageBox.Show(CusName + " Updated Successfully!!");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdateSales_Click(object sender, EventArgs e)
        {
            try
            {
                int SID = Convert.ToInt32(txtSID.Text);
                string product = txtProductSales.Text;
                string karat = txtKarat.Text;
                string Customer = txtCustomerSales.Text;
                string weight = txtWeight.Text;
                string Amount = txtAmountSales.Text;
                string Date = txtDateSales.Text;

                cm = new SqlCommand("Update tblSales set product = @product, karat = @karat, Customer = @Customer, weight = @weight, Amount = @Amount, Date = @Date where SID = @SID", con);
                cm.Parameters.AddWithValue("@product", product);
                cm.Parameters.AddWithValue("@karat", karat);
                cm.Parameters.AddWithValue("@Customer", Customer);
                cm.Parameters.AddWithValue("@weight", weight);
                cm.Parameters.AddWithValue("@Amount", Amount);
                cm.Parameters.AddWithValue("@Date", Date);

                cm.Parameters.AddWithValue("@SID", SID);

                con.Open();
                cm.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(product + " Updated Successfully!!");
                clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            try
            {
                string fullName, userName, email, password;

                fullName = txtUserFullName.Text;
                userName = txtUserName.Text;
                email = txtUserEmail.Text;
                password = txtUserPassword.Text;

                    cm = new SqlCommand("Update tblUser set password = @password, fullName = @fullName, email = @email where UName = @userName", con);
                    cm.Parameters.AddWithValue("@fullName", fullName);
                    cm.Parameters.AddWithValue("@userName", userName);
                    cm.Parameters.AddWithValue("@email", email);
                    cm.Parameters.AddWithValue("@password", password);

                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show(userName + " Updated Successfully!!");
                    clear();

                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            new RegisterForm().Show();
            this.Hide();
        }


        public void clear()
        {
            txtAmountSales.Clear();
            txtCategory.Clear();
            txtCategoryID.Clear();
            txtCategoryName.Clear();
            txtCusNoSearch.Clear();
            txtCustomerAddress.Clear();
            txtCustomerContact.Clear();
            txtCustomerName.Clear();
            txtCustomerNo.Clear();
            txtCustomerSales.Clear();
            txtDateSales.Clear();
            txtPrice.Clear();
            txtProduct.Clear();
            txtProductNo.Clear();
            txtProductSales.Clear();
            txtGram.Clear();
            txtKarat.Clear();
            txtSearchCategory.Clear();
            txtSearchProduct.Clear();
            txtSearchUser.Clear();
            txtUserName.Clear();
            txtUserFullName.Clear();
            txtUserEmail.Clear();
            txtSID.Clear();
            txtWeight.Clear();

        }

        private void btnMainForm_Click(object sender, EventArgs e)
        {
            new MainForm().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            new LoginForm().Show();
            this.Hide();

        }

        private void txtSearchUser_TextChanged(object sender, EventArgs e)
        {
            lblNote.Visible = true;
        }
    }
}
