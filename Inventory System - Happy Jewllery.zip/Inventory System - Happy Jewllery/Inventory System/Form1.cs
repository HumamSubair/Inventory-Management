﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_System
{
    public partial class LoginForm : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Inventory.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;


        public LoginForm()
        {
            InitializeComponent();
            txtPass.UseSystemPasswordChar = true;
            lblInvalid.Visible = false;
        }

        private void lblX_Click(object sender, EventArgs e)
        {
            if( MessageBox.Show("Are You sure want to Exit application?", "Application Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string userName, password;
                userName = txtUser.Text;
                password = txtPass.Text;

                cm = new SqlCommand("select * from tblUser where UName = @userName AND password = @password", con);
                cm.Parameters.AddWithValue("@userName", userName);
                cm.Parameters.AddWithValue("@password", password);
                con.Open();
                dr = cm.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {
                    new MainForm().Show();
                    this.Hide();
                }
                else
                {
                    lblInvalid.Visible = true;
                    con.Close();
                    con.Open();
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void lblRegister_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Contact Admin");
        }

        private void chkpass_CheckedChanged(object sender, EventArgs e)
        {
            if (chkpass.Checked == false)
            {
                txtPass.UseSystemPasswordChar = true;
            }
            else
            {
                txtPass.UseSystemPasswordChar = false;
            }
        }
    }
}
