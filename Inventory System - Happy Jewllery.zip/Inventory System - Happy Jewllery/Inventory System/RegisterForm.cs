﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System
{
    public partial class RegisterForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Inventory.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();


        public RegisterForm()
        {
            InitializeComponent();
            txtPassword.UseSystemPasswordChar = true;
            txtCPassword.UseSystemPasswordChar = true;
        }

        private void lblX_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure want to Exit application?", "Application Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void lbllogin_Click(object sender, EventArgs e)
        {
            new LoginForm().Show();
            this.Hide();

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string fullName, userName, email, password, ConfirmPassword;

                fullName = txtFName.Text;
                userName = txtUser.Text;
                email = txtEmail.Text;
                password = txtPassword.Text;
                ConfirmPassword = txtCPassword.Text;

                if (password == ConfirmPassword)
                {
                    cm = new SqlCommand("Insert into tblUser (fullName, UName, email, password) values (@fullName, @userName, @email, @password)", con);
                    cm.Parameters.AddWithValue("@fullName", fullName);
                    cm.Parameters.AddWithValue("@userName", userName);
                    cm.Parameters.AddWithValue("@email", email);
                    cm.Parameters.AddWithValue("@password", password);

                    con.Open();
                    cm.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Registration Done.");
                    clear();

                }
                this.Hide();
                new SubForm().Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        public void clear()
        {
            txtCPassword.Clear();
            txtEmail.Clear();
            txtFName.Clear();
            txtPassword.Clear();
            txtUser.Clear();
        }

        private void chkpass_CheckedChanged(object sender, EventArgs e)
        {
            if(chkpass.Checked == false)
            {
                txtPassword.UseSystemPasswordChar = true;
                txtCPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
                txtCPassword.UseSystemPasswordChar = false;
            }
        }
    }
}
